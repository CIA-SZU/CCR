function Population = ConstraintHanding(Population,curProgress,N)

    [alpha,infimum] = AdaptiveTolerate(Population,curProgress,N);
    CV = sum(max(0,Population.cons),2);
    Population_F = Population(CV<=0);
    Population_I = Population(CV>0);
    Feasible_num = sum(CV<=0,1);
    InFeasible_num = sum(CV>0,1);
    infimum_Feasible = ceil(infimum * N);
    if Feasible_num > ceil(N*alpha) && InFeasible_num > N - ceil(N*alpha)
        Population_I = EnvironmentalSelection_I(Population_I,N - ceil(N*alpha),Population_F,curProgress,infimum_Feasible);
        Population_F = EnvironmentalSelection_F(Population_F,ceil(N*alpha),curProgress);
    elseif InFeasible_num <= N - ceil(N*alpha)
        Population_F = EnvironmentalSelection_F(Population_F,N-InFeasible_num,curProgress);
    elseif Feasible_num <= ceil(N*alpha)
        Population_I = EnvironmentalSelection_I(Population_I,N-Feasible_num,Population_F,curProgress,infimum_Feasible);
    end
    Population = [Population_F,Population_I];  
end

function [alpha,infimum] = AdaptiveTolerate(Population,curProgress,N)
    %%
    CV = sum(max(0,Population.cons),2);
    %N=length(Population);
    [FrontNo,~] = NDSort(Population.objs,N);
    St = FrontNo==1;
    Feasible_num_NDS = length(find(CV(St)<=0));
    InFeasible_num_NDS = length(find(CV(St)>0));
    feasible_Rate = Feasible_num_NDS/(Feasible_num_NDS+InFeasible_num_NDS);
    %inFeasible_Rate = 1 - feasible_Rate;
    %control_Rate = 0.8 + inFeasible_Rate * 0.2;
    infimum = (1./(1+exp(-12*(curProgress-0.5))))*0.9+0.1;
    alpha = max(infimum,feasible_Rate);
end 
