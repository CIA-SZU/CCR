function CMaOEAAIR(Global)
% <algorithm> <A-F>
    %% Generate random population
    Population   = Global.Initialization();
    %% Optimization
    while Global.NotTermination(Population)
        curProgress = Global.evaluated/Global.evaluation;%0~1
        MatingPool = MatingSelection(Population.objs,sum(max(0,Population.cons),2),curProgress);
        Offspring  = GA(Population(MatingPool)); 
        Population = ConstraintHanding([Population,Offspring],curProgress,Global.N);
    end
end 
