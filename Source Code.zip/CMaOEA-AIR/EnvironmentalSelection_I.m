function Population_I = EnvironmentalSelection_I(Population_I,N,Population_F,curProgress,infimum_Feasible)
    
%     Population = [Population_I Population_F];
    %% Non-dominated sorting
    if length(Population_F) < infimum_Feasible && curProgress<0.3
           [FrontNo,MaxFNo] = NDSort(max(0,Population_I.cons),N);
           Flag=1;
    else
        [FrontNo,MaxFNo] = NDSort(Population_I.objs,N);
        Flag=0;
    end
    St_In = find(FrontNo < MaxFNo);
    St_Fl = find(FrontNo == MaxFNo);
    St_All = [St_In St_Fl];
    Population_I = Population_I(St_All);
    PopObj = Normalization(Population_I.objs);
    CV = sum(max(0,Population_I.cons),2);
    [NN,M]=size(PopObj);
    
    for i = 1 : NN
        temp = repmat(PopObj(i,:),NN,1) - PopObj;
        Angle(i,:) = max(temp,[],2);
    end

    corner = SelectCornerSolutions(PopObj);
    PopObj_corner = PopObj(corner,:);
    now_znad = max(PopObj_corner,[],1);
    temp_znad = max(now_znad);
    PopObj(PopObj>(temp_znad+1-curProgress))=+inf;
%     PopObj(PopObj>1+1-curProgress)=+inf;
    if Flag ==0
        Con=sum(PopObj,2);
    else
        Con=CV;
    end

    
    Angle(logical(eye(NN))) = +inf;
    Con(corner)=-inf; %M���߽��
    
    St_In_length = length(St_In);
    Remain_NDS = 1 : St_In_length;
    Remain_Fl = St_In_length+1 : length(St_All);
    
    [AAA,Con_index] = sort(Con(Remain_Fl));
    K = N - St_In_length;
    RN_A = Remain_Fl(Con_index(1:K));
    RN_B = Remain_Fl(Con_index(K+1:end));
    len_A = length(RN_A);
    len_B = length(RN_B);
    count = 0;
%     while count<min(len_A,len_B)
    while ~isempty(RN_B)
        temp = [RN_A Remain_NDS];
        if length(temp)<=1
            break;
        end
        [AA,BB] = min(Angle(RN_A,temp),[],2);
        [~,index] = min(AA);
        y = BB(index);
        if y>length(RN_A)
            bi_index = 1;
        else
            index = [index y];
            [~,bi_index]= max(Con(RN_A(index)));
        end
        RN_A_temp = RN_A;
        RN_A_temp(index(bi_index)) = [];
        [CC,DD] = min(Angle(RN_B,[Remain_NDS RN_A_temp]),[],2);
        [max_Angle,index2] = sort(CC,'descend');
        
%         if max_Angle(1) < AA(index(1))
%             break;
%         else
            [~,index3]=min(Con(RN_B(index2)));
            if CC(index2(index3)) <= AA(index(bi_index)) || Con(RN_B(index2(index3))) == +inf
                RN_B(index2(index3))=[];
            else
                r = RN_B(index2(index3));
                RN_A(index(bi_index)) = r;
                RN_B(index2(index3))=[];
            end
%         end
        count= count+1;
    end
    
    Remain = [Remain_NDS RN_A];
    Population_I = Population_I(Remain);
    
end 
