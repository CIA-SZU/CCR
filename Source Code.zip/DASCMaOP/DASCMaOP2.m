classdef DASCMaOP2 < PROBLEM
% <problem> <WFG>
% Benchmark MOP proposed by Walking Fish Group
% K --- --- The position parameter, which should be a multiple of M-1
% DifficultyFactors1 --- --- The DifficultyFactors
% DifficultyFactors2 --- --- The DifficultyFactors
% DifficultyFactors3 --- --- The DifficultyFactors

%------------------------------- Reference --------------------------------
% S. Huband, P. Hingston, L. Barone, and L. While, A review of
% multiobjective test problems and a scalable test problem toolkit, IEEE
% Transactions on Evolutionary Computation, 2006, 10(5): 477-506.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2018-2019 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    properties(Access = private)
        K;  % Position parameter
        DifficultyFactors = zeros(1,3);
    end
    methods
        %% Initialization
        function obj = DASCMaOP2()
            if isempty(obj.Global.M)
                obj.Global.M = 3;
            end
            if isempty(obj.Global.D)
                obj.Global.D = obj.Global.M + 9;
            end
            obj.K = obj.Global.ParameterSet(obj.Global.M-1);
            obj.DifficultyFactors(1) = cell2mat(obj.Global.ParameterSet(obj.Global.parameter.DASCMaOP2(2)));
            obj.DifficultyFactors(2) = cell2mat(obj.Global.ParameterSet(obj.Global.parameter.DASCMaOP2(3)));
            obj.DifficultyFactors(3) = cell2mat(obj.Global.ParameterSet(obj.Global.parameter.DASCMaOP2(4)));
            obj.Global.D        = ceil((obj.Global.D-obj.K)/2)*2 + obj.K;
            obj.Global.lower    = zeros(1,obj.Global.D);
            obj.Global.upper    = 2 : 2 : 2*obj.Global.D;
            obj.Global.encoding = 'real';
        end
        %% Calculate objective values
        function PopObj = CalObj(obj,PopDec)
            [N,D] = size(PopDec);
            M = obj.Global.M;
            K = obj.K;
            L = D - K;
            D = 1;
            S = 2 : 2 : 2*M;
            A = ones(1,M-1);

            z01 = PopDec./repmat(2:2:size(PopDec,2)*2,N,1);
            
            t1 = zeros(N,K+L);
            t1(:,1:K)     = z01(:,1:K);
            t1(:,K+1:end) = s_linear(z01(:,K+1:end),0.35);

            t2 = zeros(N,K+L/2);
            t2(:,1:K) = t1(:,1:K);
            % Same as <t2(:,i)=r_nonsep(t1(:,K+2*(i-K)-1:K+2*(i-K)),2)>
            t2(:,K+1:K+L/2) = (t1(:,K+1:2:end) + t1(:,K+2:2:end) + 2*abs(t1(:,K+1:2:end)-t1(:,K+2:2:end)))/3;
            % ---------------------------------------------------------
            
            t3 = zeros(N,M);
            for i = 1 : M-1
                t3(:,i) = r_sum(t2(:,(i-1)*K/(M-1)+1:i*K/(M-1)),ones(1,K/(M-1)));
            end
            t3(:,M) = r_sum(t2(:,K+1:K+L/2),ones(1,L/2));

            x = zeros(N,M);
            for i = 1 : M-1
                x(:,i) = max(t3(:,M),A(:,i)).*(t3(:,i)-0.5)+0.5;
            end
            x(:,M) = t3(:,M);

            h      = convex(x);
            h(:,M) = disc(x);
            PopObj = repmat(D*x(:,M),1,M) + repmat(S,N,1).*h;
        end
        
       %% Calculate constraint violations
        function PopCon = CalCon(obj,X)  
            x_all = X(:,1:1:end); 
            %sum1   = sum((x_all - sin(0.5 * pi * X(:,1))).^2,2);
  
            % set the parameters of constraints
            %DifficultyFactors = [0.5,0.5,0.25];
            DifficultyFactors = obj.DifficultyFactors;
%             DifficultyFactors = obj.DifficultyFactors{1}(1);
%             DifficultyFactors = [DifficultyFactors obj.DifficultyFactors{1}(2)];
%             DifficultyFactors = [DifficultyFactors obj.DifficultyFactors{1}(3)];
            
            eta = DifficultyFactors(1);
            zeta = DifficultyFactors(2);
            gamma = DifficultyFactors(3);
            
            % Type-I parameters
            a = 20;
            b = DifficultyFactors(1);
            c = 0.5;
            % Type-II parameters
            d = c + 10^(-2*zeta);
            % Type-III parameters
            r = 0.5 * gamma;
            
            PopObj = obj.CalObj(X);
            [N,MM] = size(PopObj);
            % Type-I constraints
            if eta > 1e-6
                for ii = 1 : (obj.Global.M-1)
                    if mod(ii,2) == 0
                        PopCon(:,ii) = repmat(b,N,1) - cos(a * pi .* X(:,ii));
                    else
                        PopCon(:,ii) = repmat(b,N,1) - sin(a * pi .* X(:,ii));
                    end
                end
            end
            % Type-II constraints
            if zeta > 1e-6
                PopCon(:,obj.Global.M) = (repmat(d,N,1) - x_all(:,obj.Global.M)).*(repmat(c,N,1) - x_all(:,obj.Global.M));
            end
            
            % Type-III constraints
            for ii = 1 : obj.Global.M
                sRange(ii) = ii*2;
            end
            
            for ii = 1 : obj.Global.M
                f(:,ii) = PopObj(:,ii)./sRange(ii);
            end
            
            for ii = 1 : obj.Global.M
                sum_c = sum(f.^2,2);
                sum_c = sum_c - f(:,ii).^2 + (f(:,ii)-1).^2 - r * r;
                PopCon(:,obj.Global.M+ii) = -sum_c;
            end
            
            %sum_c = sum((f-repmat(sqrt(1/obj.Global.M),N,MM)).^2 - repmat(r * r,N,MM),2);
            sum_c = sum((f-repmat(sqrt(1/obj.Global.M),N,MM)).^2,2) - repmat(r * r,N,1);
            
            PopCon(:,obj.Global.M*2+1) = -sum_c;
        end
        
        %% Sample reference points on Pareto front
        function P = PF(obj,N)
            M = obj.Global.M;
            P = UniformPoint(N,M);
            c = ones(size(P,1),M);
            for i = 1 : size(P,1) 
                for j = 2 : M
                    temp = P(i,j)/P(i,1)*prod(1-c(i,M-j+2:M-1));
                    c(i,M-j+1) = (temp^2-temp+sqrt(2*temp))/(temp^2+1);
                end
            end
            x = acos(c)*2/pi;
            temp = (1-sin(pi/2*x(:,2))).*P(:,M)./P(:,M-1);
            a = 0 : 0.0001 : 1;
            E = abs(temp*(1-cos(pi/2*a))-1+repmat(a.*cos(5*pi*a).^2,size(x,1),1));
            [~,rank] = sort(E,2);
            for i = 1 : size(x,1)
                x(i,1) = a(min(rank(i,1:10)));
            end
            P      = convex(x);
            P(:,M) = disc(x);
            P      = P(NDSort(P,1)==1,:);
            P      = repmat(2:2:2*M,size(P,1),1).*P;
        end
    end
end

function Output = s_linear(y,A)
    Output = abs(y-A)./abs(floor(A-y)+A);
end

function Output = r_nonsep(y,A)
    Output = zeros(size(y,1),1);
    for j = 1 : size(y,2)
        Temp = zeros(size(y,1),1);
        for k = 0 : A-2
            Temp = Temp+abs(y(:,j)-y(:,1+mod(j+k,size(y,2))));
        end
        Output = Output+y(:,j)+Temp;
    end
    Output = Output./(size(y,2)/A)/ceil(A/2)/(1+2*A-2*ceil(A/2));
end

function Output = r_sum(y,w)
    Output = sum(y.*repmat(w,size(y,1),1),2)./sum(w);
end

function Output = convex(x)
    Output = fliplr(cumprod([ones(size(x,1),1),1-cos(x(:,1:end-1)*pi/2)],2)).*[ones(size(x,1),1),1-sin(x(:,end-1:-1:1)*pi/2)];
end

function Output = disc(x)
    Output = 1-x(:,1).*(cos(5*pi*x(:,1))).^2;
end 
